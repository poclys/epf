package com.epf.rentmanager.exception;

public class DaoExeption extends Exception {

    public DaoExeption(){

    }
    
}